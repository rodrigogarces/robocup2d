/*
Copyright (c) 2000-2003, Jelle Kok, University of Amsterdam
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.

3. Neither the name of the University of Amsterdam nor the names of its
contributors may be used to endorse or promote products derived from this
software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*! \file BasicCoach.cpp
<pre>
<b>File:</b>          BasicCoach.cpp
<b>Project:</b>       Robocup Soccer Simulation Team: UvA Trilearn
<b>Authors:</b>       Jelle Kok
<b>Created:</b>       03/03/2001
<b>Last Revision:</b> $ID$
<b>Contents:</b>      This file contains the class definitions for the
                      BasicCoach which contains the main structure for the 
                      coach.
<hr size=2>
<h2><b>Changes</b></h2>
<b>Date</b>             <b>Author</b>          <b>Comment</b>
03/03/2001        Jelle Kok       Initial version created
</pre>
*/

#include"BasicCoach.h"
#include"Parse.h"
#include <sys/poll.h>

extern Logger Log; /*!< This is a reference to the Logger to write loginfo to*/

/*!This is the constructor for the BasicCoach class and contains the
   arguments that are used to initialize a coach.
   \param act ActHandler to which the actions can be sent
   \param wm WorldModel which information is used to determine action
   \param ss ServerSettings that contain parameters used by the server
   \param strTeamName team name of this player
   \param dVersion version this basiccoach corresponds to
   \param isTrainer indicates whether the coach is a trainer (offline coach)
          or an online coach (used during the match). */
BasicCoach::BasicCoach( ActHandler* act, WorldModel *wm, ServerSettings *ss,
        char* strTeamName, double dVersion, bool isTrainer ){
    char str[MAX_MSG];

    ACT       = act;
    WM        = wm;
    SS        = ss;
    bContLoop = true;
    WM->setTeamName( strTeamName );

    if( !isTrainer ){
        sprintf( str, "(init %s (version %f))", strTeamName, dVersion );
	}
    else{
        sprintf( str, "(init (version %f))", dVersion );
	}

    ACT->sendMessage( str );
}

BasicCoach::~BasicCoach( ){}

//Função que insere cada tipo numa fila
Fila *BasicCoach::insere(Fila *f, Fila *aux2){
	Fila *p;
	//Caso a fila esteja vazia
    if( f == NULL ){
        f = aux2;
	}
	else{
	    /*caso tenha pelo menos um elemento
		 * E o tipo que está sendo inserido tenha maior prioridade que o primeiro
		 * da lista.
		 */
        if( aux2->v > f->v ){
	        aux2->prox = f;
            f = aux2;
	    }
        else{
            p=f;
            //percorre a fila até encontrar sua posição na lista
            while( p->prox != NULL ){
                if( aux2->v < p->prox->v ){
                    p = p->prox;
			    }
                else{
                    break;				
                }
			}
			
            aux2->prox = p->prox;
            p->prox = aux2;            
        }
	}
    return f;
}

/*! This method is the main loop of the coach. All sequence of actions are
    located in this method. */
void BasicCoach::mainLoopNormal( ){
    #ifdef WIN32
        Sleep( 1000 );
    #else
        poll( 0, 0, 1000 );
    #endif

    bool bSubstituted = false;
    ACT->sendMessageDirect( "(eye on)" );

    #ifdef WIN32
        Sleep( 1000 );
    #else
        poll( 0, 0, 1000 );
    #endif

    /*Substituicao durante a partida, apenas quando o teammate não se movimentar
	  por mais de 200 ciclos, em estado normal de jogo*/
    while( WM->getPlayMode() != PM_TIME_OVER  && bContLoop ){	
		Log.log( 1, "in loop %d %d %f",
		         WM->getTimeLastSeeGlobalMessage().getTime(),
                 bSubstituted,
                 WM->isConfidenceGood( OBJECT_TEAMMATE_11 ));
		if(  WM->waitForNewInformation() == false ){
            printf( "Shutting down coach\n" );
            bContLoop = false;
        }
        else if( WM->getTimeLastSeeGlobalMessage().getTime() == 0 &&
                 bSubstituted == false &&
                 WM->isConfidenceGood( OBJECT_TEAMMATE_11 )){
	        Fila *x = NULL,*y = NULL,*z = NULL,*w = NULL,*aux = NULL,*p = NULL;
            // read (and write) all player_type information 
            for( int i = 0 ; i < MAX_HETERO_PLAYERS; i ++ ){
			    m_player_types[i] = WM->getInfoHeteroPlayer( i );
			    cout << i << ": " ;
			    m_player_types[i].show( cout );
			    //Rotina ainda em testes
		        //2 zagueiros e 1 meia defensivo
		        aux = (Fila*)malloc(sizeof(Fila));
		       /*Aqui o valor é transformado na faixa de 0-100 e multiplicado
				* pelo peso
		        * Versão ainda em teste.				
		        * Para cada tipo os valores podem ser calculados diferentemente,
				* exemplo:
		        * dKickableMargin(0.7-0.9)
		        * (dKickableMargin-0.7)*500 (0-100) Quanto maior o valor, maior 
				* a margem chutável
		        * (0.9-dKickableMargin)*500 (0-100) Quanto maior o valor, maior 
				* a precisão
		        */
		        aux->v = ((m_player_types[i].dStaminaIncMax-25)*5*3)+        //Recuperação
			             ((m_player_types[i].dPlayerDecay-0.4)*500*3)+        //Resistência
			             ((0.008-m_player_types[i].dDashPowerRate)*50000*4)+ //Tamanho
			             ((m_player_types[i].dKickableMargin-0.7)*500*5)+	 //Interceptação
			             ((100-m_player_types[i].dExtraStamina)*5)+			 //Esforço
			             (m_player_types[i].dSpeed*500);					 //Velocidade 
		        aux->t = i;
		        aux->prox = NULL;
		        y = insere(y,aux);
		        //2 atacantes e 1 meia ofensivo
		        aux = (Fila*)malloc(sizeof(Fila));
		        aux->v = ((45-m_player_types[i].dStaminaIncMax)*5)+			 //Velocidade
			             ((m_player_types[i].dPlayerDecay-0.4)*500*4)+		 //Resistência
			             ((m_player_types[i].dDashPowerRate-0.006)*50000*4)+ //Aceleração
			             ((0.9-m_player_types[i].dKickableMargin)*500*5)+	 //Precisão
			             ((100-m_player_types[i].dExtraStamina)*5)+			 //Esforço
			             (m_player_types[i].dSpeed*500);				  	 //Velocidade
						 
			    //O atacante não precisa de pesos pois todas essas características
			    //lhe são importantes, ou seja pesos máximos
		        aux->t = i;
		        aux->prox = NULL;
		        w = insere(w,aux);
		        //2 Laterais
		        aux = (Fila*)malloc(sizeof(Fila));
		        aux->v = ((m_player_types[i].dStaminaIncMax-25)*5*3)+		 //Recuperação
			             ((m_player_types[i].dPlayerDecay-0.4)*500*3)+		 //Resistência
			             ((0.008-m_player_types[i].dDashPowerRate)*50000*3)+ //Tamanho
			             ((m_player_types[i].dKickableMargin-0.7)*500*2)+	 //Interceptação
			             ((m_player_types[i].dExtraStamina)*4)+				 //Stamina
			             (m_player_types[i].dSpeed*500);				 	 //Velocidade
		        aux->t = i;
		        aux->prox = NULL;
		        x = insere(x,aux);
		        //1 meia defensivo e 1 meia ofensivo
		        aux = (Fila*)malloc(sizeof(Fila));
		        aux->v = ((m_player_types[i].dStaminaIncMax-25)*5*3)+		 //Recuperação
			             ((m_player_types[i].dPlayerDecay-0.4)*500*3)+		 //Drible
			             ((0.008-m_player_types[i].dDashPowerRate)*50000*3)+ //Tamanho
			             ((m_player_types[i].dKickableMargin-0.7)*500*3)+	 //Interceptação
			             ((m_player_types[i].dExtraStamina)*4)+				 //Stamina
			             (m_player_types[i].dSpeed*500);					 //Velocidade
		        aux->t = i;
		        aux->prox = NULL;
		        z = insere(z,aux);
	        }
	
            // just substitute some players (define your own methods to
            // determine which player types should be substituted )
	
            /*Resoluciona conflitos, caso tipos sejam escolhidos iguais, é selecionado
	         * o proximo da lista. Os atacantes são prioridade, são eles que mais
	         * necessitam de características heterogêneas. (velocidade, por exemplo)
	         */
	  
	        //Impressão para teste
	        //cout<<"fila de prioridades:"<<endl<<"atacantes"<<endl;
	        p = w;
	        while(p != NULL){
		        //cout<<p->t<<endl;
		        p = p->prox;
	        }
	        //cout<<"fila de prioridades:"<<endl<<"defensores"<<endl;
	        p = y;
	        while(p != NULL){
		        //cout<<p->t<<endl;
		        p = p->prox;
	        }
	        //cout<<"fila de prioridades:"<<endl<<"laterais"<<endl;
	        p = x;
	        while(p != NULL){
		        //cout<<p->t<<endl;
		        p = p->prox;
	        }
	        //cout<<"fila de prioridades:"<<endl<<"meias"<<endl;
	        p = z;
	        while(p != NULL){
		        //cout<<p->t<<endl;
		        p = p->prox;
	        }
	  
	        substitutePlayer(  9, w->t );
            substitutePlayer( 10, w->t );
            substitutePlayer( 11, w->t );
	        if( y->t == w->t ){
		        y = y->prox;
			}
            substitutePlayer(  3, y->t );
            substitutePlayer(  4, y->t );
	        substitutePlayer(  2, y->t );
	        while(( x->t == w->t )||( x->t == y->t )){
		        x=x->prox;
	        }
	        substitutePlayer(  8, x->t );
            substitutePlayer(  5, x->t );
	        /*while(( z->t == w->t )||( z->t == y->t )||( z->t == x->t )){			
		          z = z->prox;
		      }
              substitutePlayer(  7, z->t );
              substitutePlayer(  6, z->t );
	        */
           bSubstituted = true;
        }
  
        if( Log.isInLogLevel(  456 ) ){
            WM->logObjectInformation( 456, OBJECT_ILLEGAL);
		}
        if( SS->getSynchMode() == true ){
            ACT->sendMessageDirect( "(done)" );
		}
    }
	
    return;
}


/*! This method substitutes one player to the given player type and sends
    this command (using the ActHandler) to the soccer server. */
void BasicCoach::substitutePlayer( int iPlayer, int iPlayerType ){
    SoccerCommand soc;
    soc.makeCommand( CMD_CHANGEPLAYER, (double)iPlayer, (double)iPlayerType );
    ACT->sendCommandDirect( soc );
    cerr << "coachmsg: changed player " << iPlayer << " to type " << iPlayerType
         << endl;
}

void* stdin_callback( void * v ){
    Log.log( 1, "Starting to listen for user input" );
    BasicCoach* bc = (BasicCoach*)v;
    bc->handleStdin();
    return NULL;
}

/*!This method listens for input from the keyboard and when it receives this
   input it converts this input to the associated action. See
   showStringCommands for the possible options. This method is used together
   with the SenseHandler class that sends an alarm to indicate that a new
   command can be sent. This conflicts with the method in this method that
   listens for the user input (fgets) on Linux systems (on Solaris this isn't a
   problem). The only known method is to use the flag SA_RESTART with this
   alarm function, but that does not seem to work under Linux. If each time
   the alarm is sent, this gets function unblocks, it will cause major
   performance problems. This function should not be called when a whole match
   is played! */
void BasicCoach::handleStdin( ){
    char buf[MAX_MSG];

    while( bContLoop ){
        #ifdef WIN32
            cin.getline( buf, MAX_MSG );
        #else
            fgets( buf, MAX_MSG, stdin ); // does unblock with signal !!!!!
        #endif
        printf( "after fgets: %s\n", buf );
        executeStringCommand( buf );
    }
}

/*!This method prints the possible commands that can be entered by the user.
   The whole name can be entered to perform the corresponding command, but
   normally only the first character is sufficient. This is indicated by
   putting brackets around the part of the command that is not needed.
   \param out output stream to which the possible commands are printed */
void BasicCoach::showStringCommands( ostream& out ){
    out << "Basic commands:"                                << endl <<
           " m(ove) player_nr x y"                          << endl <<
           " q(uit)"                                        << endl;
}

/*!This method executes the command that is entered by the user. For the
   possible command look at the method showStringCommands.
   \param str string that is entered by the user
   \return true when command could be executed, false otherwise */
bool BasicCoach::executeStringCommand( char *str){
    switch( str[0] ){
        case 'm':                               // move
            sprintf( str, "(move %d %f %f)", Parse::parseFirstInt( &str ),
                                             Parse::parseFirstDouble( &str ),
                                             Parse::parseFirstDouble( &str ) );
        break;
        case 'q':                             // quit
            bContLoop = false;
            return true;
        default:                             // default: send entered string
        ;
    }
    printf( "send: %s\n", str );
    ACT->sendMessage( str );
    return true;
}
