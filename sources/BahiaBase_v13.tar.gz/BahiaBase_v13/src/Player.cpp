#include "Player.h"
#include "Parse.h"
#include "stdio.h"
#include <fstream>

#ifndef WIN32
  #include <sys/poll.h> // needed for 'poll'
#endif

extern Logger LogDraw;

/*!This method can be called in a separate thread (see pthread_create) since
   it returns a void pointer. It is assumed that this function receives a
   BasicPlayer class as argument. The only thing this function does
   is starting the method handleStdin() from the corresponding BasicPlayer
   class that listens to user input from the keyboard. This function is
   necessary since a method from a class cannot be an argument of
   pthread_create.
   \param v void pointer to a BasicPlayer class.
   \return should never return since function handleStdin has infinite loop*/
void* stdin_callback( void * v ){
    Log.log( 1, "Starting to listen for user input" );
    Player* p = (Player*)v;
    p->handleStdin();
    return NULL;
}

/*!This is the constructor the Player class and calls the constructor of the
   superclass BasicPlayer.
   \param act ActHandler to which the actions can be sent
   \param wm WorldModel which information is used to determine action
   \param ss ServerSettings that contain parameters used by the server
   \param ps PlayerSettings that contain parameters important for the client
   \param strTeamName team name of this player
   \param dVersion version this basicplayer corresponds to
   \param iReconnect integer that defines player number (-1 when new player) */

Player::Player( ActHandler     *act,     WorldModel     *wm,
                ServerSettings *ss,      PlayerSettings *ps,
                Formations     *fs,      char*          strTeamName,
                double         dVersion, int            iReconnect   ){
    char str[MAX_MSG];
    ACT           = act;
    WM            = wm;
    SS            = ss;
    PS            = ps;
    formations    = fs;
    bContLoop     = true;
    m_iPenaltyNr  = -1;
    WM->setTeamName( strTeamName );
    m_timeLastSay = -5;
    m_objMarkOpp  = OBJECT_ILLEGAL;
    m_actionPrev  = ACT_ILLEGAL;

    // wait longer as role number increases, to make sure players appear at the
    // field in the correct order
    #ifdef WIN32
        Sleep( formations->getPlayerInFormation()*500 );
    #else
        poll( 0, 0, formations->getPlayerInFormation()*500 );
    #endif

    // create initialisation string
    if( iReconnect != -1 )
        sprintf( str, "(reconnect %s %d)", strTeamName, iReconnect );
    else if( formations->getPlayerType() == PT_GOALKEEPER ){
        sprintf( str, "(init %s (version %f) (goalie))", strTeamName, dVersion );
    }else
        sprintf( str, "(init %s (version %f))", strTeamName, dVersion );
    ACT->sendMessage( str );
}

/*! This is the main loop of the agent. This method calls the update methods
    of the world model after it is indicated that new information has arrived.
    After this, the correct main loop of the player type is called, which
    puts the best soccer command in the queue of the ActHandler. */

void Player::mainLoop( ){
    char str[MAX_MSG];
    Timing timer;
    // wait for new information from the server
    // cannot say bContLoop=WM->wait... since bContLoop can be changed elsewhere
    if(  WM->waitForNewInformation() == false )
        bContLoop =  false;

    // and set the clang version
    sprintf( str, "(clang (ver 8 8))" );
    ACT->sendMessage( str );

    while( bContLoop ){        // as long as server alive

        Log.logWithTime( 3, "  start update_all" );
        Log.setHeader( WM->getCurrentCycle() );
        LogDraw.setHeader( WM->getCurrentCycle() );
        if( WM->updateAll( ) == true ){
		    //Solução temporária para formação nas cobranças de meio-de-campo
  		    if(formations->getFormation() == FT_INITIAL){
                formations->setFormation(FT_433_OFFENSIVE);
            }
		    timer.restartTime();
            SoccerCommand soc(CMD_ILLEGAL);
            if( ( WM->isPenaltyUs( ) || WM->isPenaltyThem() ) ){
        	    soc = performPenalty();
            }
            else{
				switch( formations->getPlayerType( ) ){        // determine right loop
			  	    case PT_GOALKEEPER:		    soc = acaoDummyGoleiro();   break;
			  	    case PT_DEFENDER_SWEEPER:	soc = acaoDummyLinha();     break;
			  	    case PT_DEFENDER_CENTRAL:	soc = acaoDummyLinha();     break;
				    case PT_DEFENDER_WING:	    soc = acaoDummyLinha();     break;
				    case PT_MIDFIELDER_CENTER:	soc = acaoDummyLinha();     break;
				    case PT_MIDFIELDER_WING:	soc = acaoDummyLinha();     break;
				    case PT_ATTACKER:	        soc = acaoDummyLinha();     break;
				    case PT_ATTACKER_WING:	    soc = acaoDummyLinha();     break;
				    case PT_ILLEGAL:
				    default: break;
			    }
      	    }

		    //COLOCANDO O COMANDO NA LISTA
		    ACT->putCommandInQueue(soc);

		    //COMUNICAÇÃO
		    if( shallISaySomething(soc) == true )
		    {
			    m_timeLastSay = WM->getCurrentTime();
			    char strMsg[MAX_SAY_MSG];
			    if( WM->getPlayerNumber() == 6 &&
				    WM->getBallPos().getX() < - PENALTY_X + 4.0  )
				    sayOppAttackerStatus( strMsg );
			    else
				    sayBallStatus( strMsg );
			    if( strlen( strMsg ) != 0 )
				    Log.log( 600, "send communication string: %s", strMsg );
			    WM->setCommunicationString( strMsg );
		    }
		    Log.logWithTime( 3, "  determined action; waiting for new info" );

            // directly after see message, will nog get better info, so send commands
            if( WM->getTimeLastSeeMessage() == WM->getCurrentTime() ||
              ( SS->getSynchMode() == true &&  WM->getRecvThink() == true )){
                    ACT->sendCommands( );
        	        Log.logWithTime( 3, "  sent messages directly" );
			        if( SS->getSynchMode() == true  ){
			            WM->processRecvThink( false );
			            ACT->sendMessageDirect( "(done)" );
			        }
      	        }
        }
        else
            Log.logWithTime( 3, "  HOLE no action determined; waiting for new info");

	    if( WM->getCurrentCycle()%(SS->getHalfTime()*SS->getSimulatorStep()) != 0 ){
      	    if( LogDraw.isInLogLevel( 600 ) )
        	    WM->logDrawInfo( 600 );
      	    if( LogDraw.isInLogLevel( 601 ) )
        	    WM->logDrawBallInfo( 601 );
      	    if( LogDraw.isInLogLevel( 700 ) )
        	    WM->logCoordInfo( 700 );
        }
        Log.logWithTime( 604, "time for action: %f", timer.getElapsedTime()*1000 );

        // wait for new information from the server cannot say
        // bContLoop=WM->wait... since bContLoop can be changed elsewhere
        if(  WM->waitForNewInformation() == false )
            bContLoop =  false;
  	}

    // shutdow, print hole and number of players seen statistics
    printf("Jogador Finalizado %d\n", WM->getPlayerNumber() );
}

/*! This method is called when a penalty kick has to be taken (for both the
  goalkeeper as the player who has to take the penalty. */
SoccerCommand Player::performPenalty(){
	SoccerCommand soc(CMD_ILLEGAL);
	if(formations->getPlayerType() == PT_GOALKEEPER){
		soc = performPenaltyGoalKeeper();
	}
    else{
		soc = performPenaltyPlayer();
	}
	return soc;
}

/*! Este metodo encapsula as decisoes tomadas pelo goleiro durante as cobrancas
    de penalti, como posicionamento e defesa.

    \return SoccerCommand que representa a acao tomada pelo goleiro  */
SoccerCommand Player::performPenaltyGoalKeeper(){
	SoccerCommand soc(CMD_ILLEGAL);

	int iSide = (WM->getSide() == WM->getSidePenalty())? -1 : 1;

	double limiteGoleiro = iSide*37.50;

	static PlayModeT pmPrev = PM_ILLEGAL;

	if( WM->isPenaltyThem( ) ){
		if( WM->isPenaltyAutorizado() ){ //Inicio de Penalty Taken
			if( pmPrev == PM_PENALTY_SETUP_LEFT ||
				pmPrev == PM_PENALTY_SETUP_RIGHT ){
			    soc = moveToPos(VecPosition(limiteGoleiro,0.0),10);
			}
			else{
				soc = acaoDefesaPenalty();
			}
		}//Fim de Penalty Taken
		else{
		    soc = posicionamentoPenaltyGoleiro();
		}
	}
	else{
		soc = posicionamentoPenaltyGoleiro();
	}
	if(WM->getAgentStamina().getStamina() <
       SS->getRecoverDecThr()*SS->getStaminaMax()+ 500 &&
       soc.commandType == CMD_DASH)
	    soc.dPower = 30;

	pmPrev = WM->getPlayMode();
	return soc;
}

/*! Rotina responsavel pelo posicionamento do goleiro antes de uma cobranca de
    penalti. Aqui e decidido onde o goleiro se posicionara de acordo com o time
    que deve cobrar o penalti.

    \return SoccerCommand que move (ou ajeita) o agente para a posicao ideal  */
SoccerCommand Player::posicionamentoPenaltyGoleiro(){
	SoccerCommand soc;
	VecPosition pos;
	int iSide = (WM->getSide() == WM->getSidePenalty())? -1 : 1;
	if( WM->isPenaltyThem( ) ){
		pos = VecPosition(iSide*50,0.0);
		soc = moveToPos(pos,10);
		ACT->putCommandInQueue(SoccerCommand( CMD_CHANGEVIEW, VA_WIDE, VQ_HIGH ));
	}
	else{
		pos = VecPosition( iSide * (PITCH_LENGTH/2.0 + 2 ) , 25 );
		soc = moveToPos(pos,10);
	}
	return soc;
}

/*! Rotina responsavel pelo raciocinio do goleiro durante uma cobranca de
    penalti do adversario. Atraves das posicoes do goleiro, do adversario e da
    bola, entre outras percepcoes, o agente decide de forma reativa como ira
    defender o penalti.

    \return SoccerCommand que move (ou ajeita) o agente para a posicao ideal  */
SoccerCommand Player::acaoDefesaPenalty(){
	int iSide                       = (WM->getSide() == WM->getSidePenalty())? -1 : 1;
	int i;

	VecPosition posPenalty( iSide*(52.5 - SS->getPenDistX()), 0.0 );
	VecPosition pos                 = posPenalty;
	VecPosition posAgent            = WM->getAgentGlobalPosition();
	VecPosition posBola             = WM->getBallPos();
	VecPosition posMyGoal           = WM->getPosOwnGoal();

	double limiteGoleiro            = iSide*37.50;

	static const VecPosition posLeftTop(limiteGoleiro,-20.175); //valor da flag do penalty
	static const VecPosition posRightTop(limiteGoleiro,20.175);

	static Line  lineFront          = Line::makeLineFromTwoPoints(posLeftTop,posRightTop);
	static Line  lineLeft           = Line::makeLineFromTwoPoints(VecPosition( iSide*52.5, posLeftTop.getY()), posLeftTop );
	static Line  lineRight          = Line::makeLineFromTwoPoints(VecPosition( iSide*52.5, posRightTop.getY()),posRightTop );

	Line lineBall                   = Line::makeLineFromTwoPoints(posBola,posMyGoal);

	VecPosition posInterceptBall    = lineFront.getIntersection( lineBall );

	list <ObjectT> listaAdversarios = WM->getListCloseOpponents(posAgent,10);

	ObjectT adversario              = listaAdversarios.front();

	VecPosition posAdv              = WM->getGlobalPosition(adversario);

	bool moveBack                   = true;

	SoccerCommand soc(CMD_ILLEGAL);

	if(WM->getConfidence( OBJECT_BALL ) < PS->getBallConfThr()){
		ACT->putCommandInQueue( searchBall() );
	}

	if(WM->isBallCatchable()){
		soc = catchBall();
	}
	else if(WM->amIFastestAgentTo(OBJECT_SET_PLAYERS, OBJECT_BALL)
			&& (fabs(posBola.getX()) >= 36)){
		soc = intercept( true );
	}
	else if (fabs(posBola.getX()) >= fabs(limiteGoleiro)){
	    double distancia = (fabs(posMyGoal.getX())-fabs(posBola.getX())) / 2;

	    VecPosition posTeste(0.0,0.0);

	    posTeste.setX(iSide*(fabs(posBola.getX())+distancia));

	    if (WM->isLateralATT(posBola) || WM->isLateralDEF(posBola)){
		    double y = (posBola.getY() > 0)? 10.0 : -10.0;
		    posTeste.setY(y);
	    }
	    else{
		    posTeste.setY(lineBall.getYGivenX(posTeste.getX()));
	    }
	    if(fabs(posTeste.getX()) < fabs(posAgent.getX())){
		    moveBack = false;
	    }
	    soc = moveToPos(posTeste,PS->getPlayerWhenToTurnAngle(),moveBack);
	}
	else{
		if(posInterceptBall.isRightOf( posRightTop )){
		    posInterceptBall = lineRight.getIntersection( lineBall );
		}
	    else if (posInterceptBall.isLeftOf( posLeftTop ) ){
			posInterceptBall = lineLeft.getIntersection( lineBall );
		}
	    if( fabs(posInterceptBall.getX()) > fabs(limiteGoleiro)){
			posInterceptBall.setX( limiteGoleiro );
		}
	    if(fabs(posInterceptBall.getX()) < fabs(posAgent.getX())){
		    moveBack = false;
		}
	    soc = moveToPos(posInterceptBall,PS->getPlayerWhenToTurnAngle(),moveBack);
	}
	return soc;
}

/*! Rotina responsavel pelo posicionamento do atacante antes de uma cobranca de
    penalti. Aqui e decidido onde o agente se posicionara de acordo com o time
    que deve cobrar o penalti e se ele e o agente que deve cobrar o penalti para
    o seu time.

    \return SoccerCommand que move (ou ajeita) o agente para a posicao ideal  */
SoccerCommand Player::performPenaltyPlayer( ){
    SoccerCommand soc(CMD_ILLEGAL);

    if(WM->isNewPenalty())
        m_iPenaltyNr++;

    if( isCobrarPenalty() ){
        if(WM->isPenaltyAutorizado()){
		    soc = acaoCobrancaPenalty();
	    }
	    else{
		    soc = posicionamentoPenaltyPlayer();
	    }
    }
    else{
	    soc = posicionamentoPenaltyPlayer();
    }

    if(WM->getAgentStamina().getStamina() <
       SS->getRecoverDecThr()*SS->getStaminaMax() + 500 &&
       soc.commandType == CMD_DASH)
        soc.dPower = 30;
    return soc;
}

/*! Rotina responsavel pelo posicionamento do atacante antes de uma cobranca de
    penalti. Aqui e decidido onde o agente se posicionara de acordo com o time
    que deve cobrar o penalti e se ele e o agente que deve cobrar o penalti para
    o seu time.

    \return SoccerCommand que move (ou ajeita) o agente para a posicao ideal  */
SoccerCommand Player::posicionamentoPenaltyPlayer(){
	SoccerCommand soc;

	int iSide = (WM->getSide() == WM->getSidePenalty())? -1 : 1;

	VecPosition pos;
	VecPosition posPenalty(iSide*(52.5-SS->getPenDistX()),0.0);
	VecPosition posAgent = WM->getAgentGlobalPosition();

	AngDeg angBody = WM->getAgentGlobalBodyAngle();

	if( isCobrarPenalty( ) ){
		pos = posPenalty - VecPosition( iSide*2.0, 0 );
		if(fabs( posAgent.getX() ) > fabs( pos.getX() ) ){
			pos = posPenalty;
		}
		if( pos.getDistanceTo( posAgent ) < 0.6 ){
			pos = posPenalty;
			if(fabs(VecPosition::normalizeAngle((pos-posAgent).getDirection() - angBody))>20)
				soc = turnBodyToPoint( pos );
		}
        else{
		    soc = moveToPos( pos, 10);
		}
	}
	else{
		pos = VecPosition( 5.0,VecPosition::normalizeAngle(iSide*(50 + 20*WM->getPlayerNumber())),POLAR );
		soc = moveToPos(pos,10);
	}
	return soc;
}

/*! Rotina responsavel pelo raciocinio do atacante durante sua cobranca de
    penalti. Atraves das posicoes do goleiro e da bola, entre outras percepcoes,
    o agente decide, de forma reativa, se dribla, chuta, carrega a bola ou se
    aproxima do gol, bem como a maneira com que isso sera feito (atraves de
    metodos proprios do penalti, diferentes do modo de jogo normal).

    \return SoccerCommand que representa a acao tomada pelo atacante */
SoccerCommand Player::acaoCobrancaPenalty(){
    int           iSide         = (WM->getSide()==WM->getSidePenalty()) ? -1 : 1;

    VecPosition   posAgent      = WM->getAgentGlobalPosition();
    VecPosition   posChute      = VecPosition(52.5,0.0);
    if(WM->getSide()== SIDE_RIGHT ){
    	posChute      = VecPosition(-52.5,0.0);
    }
    VecPosition   posOpp        = WM->getGlobalPosition(OBJECT_OPPONENT_GOALIE);
    VecPosition   posGoal       = WM->getPosOpponentGoal();
    VecPosition   pos;

    double        xTeste        = fabs(posOpp.getX()+15);
    double        yTeste        = fabs(posOpp.getY()+35);
    double        posY          = (((posOpp.getY()<=0)?1:-1)*yTeste);
    double        posXToque     = fabs(posAgent.getX());
    double        posYToque     = ((posAgent.getY()<=0)?7:-7);

    VecPosition   posToque        (iSide*posXToque,posYToque);
    VecPosition   posCarrega      (iSide*xTeste,posY);

    AngDeg        angBody       = WM->getAgentGlobalBodyAngle();
    AngDeg        angGoleiro    = WM->getRelativeAngle(OBJECT_OPPONENT_GOALIE,true);

    Circle        cirAgen       = Circle(posAgent,7);
    Circle        cirOpp        = Circle(posOpp,7);

    int           ptsInter      = cirAgen.getIntersectionPoints(cirOpp,&posToque,&posCarrega);

    SoccerCommand soc(CMD_ILLEGAL);

	if(WM->getConfidence(OBJECT_BALL) < PS->getBallConfThr()){
	    ACT->putCommandInQueue(soc = searchBall());
	}

	if (!WM->isBallKickable()){
		soc = intercept(false);
	}

	else if (WM->isMeioCampoATT(posAgent)||
	         WM->isMeioCampoDEF(posAgent)){

		if (isChutePenalty()){
			posChute.setX(iSide*fabs(posChute.getX()));
			soc = bicuda(posChute);
		}
		else{
			soc = carregarBola(posGoal.getDirection(),DRIBBLE_WITHBALL,posChute.getDirection());
		}

	}
	else if (WM->isInterMediareaATT(posAgent)||
			 WM->isInterMediareaDEF(posAgent)){

		if (isChutePenalty()){
		    posChute.setX(iSide*fabs(posChute.getX()));
			soc = bicuda(posChute);
		}
		else if (posAgent.getDistanceTo(posOpp)>15){
		    soc = carregarBola(posGoal.getDirection(),DRIBBLE_WITHBALL,posChute.getDirection());
		}
		else if (posAgent.getDistanceTo(posOpp)<=15){
			if (ptsInter>=1){
			    if (posAgent.getDistanceTo(posToque)>posAgent.getDistanceTo(posCarrega)){
		    		soc=kickTo(posCarrega,0.5);
				}
				else{
					soc=kickTo(posToque,0.5);
				}
			}
			else{
			    soc = carregarBola(posGoal.getDirection(),DRIBBLE_FAST,posChute.getDirection());
			}
		}
	}
	else if (WM->isLateralATT(posAgent)||
			 WM->isLateralDEF(posAgent)){

		if (isChutePenalty()){
		    posChute.setX(iSide*fabs(posChute.getX()));
			soc = bicuda(posChute);
		}
		else{
			soc = carregarBola(angBody,DRIBBLE_WITHBALL,angGoleiro);
		}
	}
	else if (WM->isGrandeAreaATT(posAgent)||
			 WM->isGrandeAreaDEF(posAgent)){

		if (isChutePenalty()){
	        posChute.setX(iSide*fabs(posChute.getX()));
			soc = bicuda(posChute);
		}
		else if (ptsInter>=1){
			if (posAgent.getDistanceTo(posToque)>posAgent.getDistanceTo(posCarrega)){
				soc=kickTo(posCarrega,0.5);
			}
			else{
				soc=kickTo(posToque,0.5);
			}
		}
		else{
			soc = carregarBola(posGoal.getDirection(),DRIBBLE_WITHBALL,posChute.getDirection());
		}
	}
	return soc;
}

/*! Metodo que retorna um chute de potencia maxima para o ponto desejado.

    \param posChute posicao do campo para onde se deseja chutar
    \return SoccerCommand chute de forca maxima para um dado ponto */
SoccerCommand Player::bicuda(VecPosition posChute){
	return kickTo(posChute,SS->getBallSpeedMax());
}

/*! Este metodo retorna se o atacante esta em uma boa situacao para um chute ao
    gol em uma cobrança de penalti.

    \return bool que indica se existe uma boa chance de gol apos um chute  */
bool Player::isChutePenalty(){
    int      iSide         = (WM->getSide()==WM->getSidePenalty()) ? -1 : 1;

	VecPosition posGoleiro=WM->getGlobalPosition(OBJECT_OPPONENT_GOALIE);
	VecPosition posAgent =WM->getAgentGlobalPosition();

    double        posY          = (((posAgent.getY()<=0)?1:-1)*3.5);

	VecPosition   posEnd      (iSide*(52.5),posY);

	double distancia = WM->getRelDistanceOpponentGoal();

    if (distancia<20 && posAgent.getDistanceTo(posGoleiro)>5){
        if ((fabs(posAgent.getX()))>(fabs(posGoleiro.getX()))){
	        return true;
	    }
	    else if (WM->getNrInSetInCone(OBJECT_SET_OPPONENTS,3.5,posAgent,posEnd)){
	        return true;
	    }
    }
	return false;
}

/*! Metodo que retorna se o agente e quem deve cobrar o penalti.

    \return bool que indica se o agente e quem deve cobrar o penalti  */
bool Player::isCobrarPenalty(){
	return (WM->isPenaltyUs() && WM->getPlayerNumber() == (11 - (m_iPenaltyNr % 11)));
}

SoccerCommand Player::acaoDummyLinha(){
	SoccerCommand soc(CMD_ILLEGAL);
  VecPosition   posAgent = WM->getAgentGlobalPosition();
  VecPosition   posBall  = WM->getBallPos();
  int           iTmp;

  if( WM->isBeforeKickOff( ) )
  {
	if( WM->isKickOffUs( ) && WM->getPlayerNumber() == 9 ) // 9 takes kick
	{
	  if( WM->isBallKickable() )
	  {
		VecPosition posGoal( PITCH_LENGTH/2.0,
							 (-1 + 2*(WM->getCurrentCycle()%2)) *
							 0.4 * SS->getGoalWidth() );
		soc = kickTo( posGoal, SS->getBallSpeedMax() ); // kick maximal
		Log.log( 100, "take kick off" );
	  }
	  else
	  {
		soc = intercept( false );
		Log.log( 100, "move to ball to take kick-off" );
	  }
	  ACT->putCommandInQueue( soc );
	  ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  return soc;
	}
	if( formations->getFormation() != FT_INITIAL || // not in kickoff formation
		posAgent.getDistanceTo( WM->getStrategicPosition() ) > 2.0 )
	{
	  formations->setFormation( FT_INITIAL );       // go to kick_off formation
	  ACT->putCommandInQueue( soc=teleportToPos( WM->getStrategicPosition() ));
	}
	else                                            // else turn to center
	{
	  ACT->putCommandInQueue( soc=turnBodyToPoint( VecPosition( 0, 0 ), 0 ) );
	  ACT->putCommandInQueue( alignNeckWithBody( ) );
	}
  }
  else
  {
	formations->setFormation( FT_433_OFFENSIVE );
	soc.commandType = CMD_ILLEGAL;

	if( WM->getConfidence( OBJECT_BALL ) < PS->getBallConfThr() )
	{
	  ACT->putCommandInQueue( soc = searchBall() );   // if ball pos unknown
	  ACT->putCommandInQueue( alignNeckWithBody( ) ); // search for it
	}
	else if( WM->isBallKickable())                    // if kickable
	{
	  VecPosition posGoal( PITCH_LENGTH/2.0,
			  (-1 + 2*(WM->getCurrentCycle()%2)) * 0.4 * SS->getGoalWidth() );
	  soc = kickTo( posGoal, SS->getBallSpeedMax() ); // kick maximal

	  ACT->putCommandInQueue( soc );
	  ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  Log.log( 100, "kick ball" );
	}
	else if( WM->getFastestInSetTo( OBJECT_SET_TEAMMATES, OBJECT_BALL, &iTmp )
			  == WM->getAgentObjectType()  && !WM->isDeadBallThem() )
	{                                                // if fastest to ball
	  Log.log( 100, "I am fastest to ball; can get there in %d cycles", iTmp );
	  soc = intercept( false );                      // intercept the ball

	  if( soc.commandType == CMD_DASH &&             // if stamina low
		  WM->getAgentStamina().getStamina() <
			 SS->getRecoverDecThr()*SS->getStaminaMax()+200 )
	  {
		soc.dPower = 30.0 * WM->getAgentStamina().getRecovery(); // dash slow
		ACT->putCommandInQueue( soc );
		ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  }
	  else                                           // if stamina high
	  {
		ACT->putCommandInQueue( soc );               // dash as intended
		ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  }
	 }
	 else if( posAgent.getDistanceTo(WM->getStrategicPosition()) >
				  1.5 + fabs(posAgent.getX()-posBall.getX())/10.0)
												  // if not near strategic pos
	 {
	   if( WM->getAgentStamina().getStamina() >     // if stamina high
							SS->getRecoverDecThr()*SS->getStaminaMax()+800 )
	   {
		 soc = moveToPos(WM->getStrategicPosition(),
						 PS->getPlayerWhenToTurnAngle());
		 ACT->putCommandInQueue( soc );            // move to strategic pos
		 ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	   }
	   else                                        // else watch ball
	   {
		 ACT->putCommandInQueue( soc = turnBodyToObject( OBJECT_BALL ) );
		 ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	   }
	 }
	 else if( fabs( WM->getRelativeAngle( OBJECT_BALL ) ) > 1.0 ) // watch ball
	 {
	   ACT->putCommandInQueue( soc = turnBodyToObject( OBJECT_BALL ) );
	   ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	 }
	 else                                         // nothing to do
	   ACT->putCommandInQueue( SoccerCommand(CMD_TURNNECK,0.0) );
   }
  return soc;
}


SoccerCommand Player::acaoDummyGoleiro(){
	  int i;
	  SoccerCommand soc;
	  VecPosition   posAgent = WM->getAgentGlobalPosition();
	  AngDeg        angBody  = WM->getAgentGlobalBodyAngle();

	  // define the top and bottom position of a rectangle in which keeper moves
	  static const VecPosition posLeftTop( -PITCH_LENGTH/2.0 +
	               0.7*PENALTY_AREA_LENGTH, -PENALTY_AREA_WIDTH/4.0 );
	  static const VecPosition posRightTop( -PITCH_LENGTH/2.0 +
	               0.7*PENALTY_AREA_LENGTH, +PENALTY_AREA_WIDTH/4.0 );

	  // define the borders of this rectangle using the two points.
	  static Line  lineFront = Line::makeLineFromTwoPoints(posLeftTop,posRightTop);
	  static Line  lineLeft  = Line::makeLineFromTwoPoints(
	                         VecPosition( -50.0, posLeftTop.getY()), posLeftTop );
	  static Line  lineRight = Line::makeLineFromTwoPoints(
	                         VecPosition( -50.0, posRightTop.getY()),posRightTop );


	  if( WM->isBeforeKickOff( ) )
	  {
	    if( formations->getFormation() != FT_INITIAL || // not in kickoff formation
	        posAgent.getDistanceTo( WM->getStrategicPosition() ) > 2.0 )
	    {
	      formations->setFormation( FT_INITIAL );       // go to kick_off formation
	      ACT->putCommandInQueue( soc=teleportToPos(WM->getStrategicPosition()) );
	    }
	    else                                            // else turn to center
	    {
	      ACT->putCommandInQueue( soc = turnBodyToPoint( VecPosition( 0, 0 ), 0 ));
	      ACT->putCommandInQueue( alignNeckWithBody( ) );
	    }
	    return soc;
	  }

	  if( WM->getConfidence( OBJECT_BALL ) < PS->getBallConfThr() )
	  {                                                // confidence ball too  low
	    ACT->putCommandInQueue( searchBall() );        // search ball
	    ACT->putCommandInQueue( alignNeckWithBody( ) );
	  }
	  else if( WM->getPlayMode() == PM_PLAY_ON || WM->isFreeKickThem() ||
	           WM->isCornerKickThem() )
	  {
	    if( WM->isBallCatchable() )
	    {
	      ACT->putCommandInQueue( soc = catchBall() );
	      ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	    }
	     else if( WM->isBallKickable() )
	    {
	       soc = kickTo( VecPosition(0,posAgent.getY()*2.0), 2.0 );
	       ACT->putCommandInQueue( soc );
	       ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	    }
	    else if( WM-> isGrandeAreaDEF( getInterceptionPointBall( &i, true ) ) &&
	             WM->getFastestInSetTo( OBJECT_SET_PLAYERS, OBJECT_BALL, &i ) ==
	                                               WM->getAgentObjectType() )
	    {
	      ACT->putCommandInQueue( soc = intercept( true ) );
	      ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	    }
	    else
	    {
	      // make line between own goal and the ball
	      VecPosition posMyGoal = ( WM->getSide() == SIDE_LEFT )
	             ? SoccerTypes::getGlobalPositionFlag(OBJECT_GOAL_L, SIDE_LEFT )
	             : SoccerTypes::getGlobalPositionFlag(OBJECT_GOAL_R, SIDE_RIGHT);
	      Line lineBall = Line::makeLineFromTwoPoints( WM->getBallPos(),posMyGoal);

	      // determine where your front line intersects with the line from ball
	      VecPosition posIntersect = lineFront.getIntersection( lineBall );

	      // outside rectangle, use line at side to get intersection
	      if (posIntersect.isRightOf( posRightTop ) )
	        posIntersect = lineRight.getIntersection( lineBall );
	      else if (posIntersect.isLeftOf( posLeftTop )  )
	        posIntersect = lineLeft.getIntersection( lineBall );

	      if( posIntersect.getX() < -49.0 )
	        posIntersect.setX( -49.0 );

	      // and move to this position
	      if( posIntersect.getDistanceTo( WM->getAgentGlobalPosition() ) > 0.5 )
	      {
	        soc = moveToPos( posIntersect, PS->getPlayerWhenToTurnAngle() );
	        ACT->putCommandInQueue( soc );
	        ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	      }
	      else
	      {
	        ACT->putCommandInQueue( soc = turnBodyToObject( OBJECT_BALL ) );
	        ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	      }
	    }
	  }
	  else if( WM->isFreeKickUs() == true || WM->isGoalKickUs() == true )
	  {
	    if( WM->isBallKickable() )
	    {
	      if( WM->getTimeSinceLastCatch() == 25 && WM->isFreeKickUs() )
	      {
	        // move to position with lesser opponents.
	        if( WM->getNrInSetInCircle( OBJECT_SET_OPPONENTS,
	                                          Circle(posRightTop, 15.0 )) <
	            WM->getNrInSetInCircle( OBJECT_SET_OPPONENTS,
	                                           Circle(posLeftTop,  15.0 )) )
	          soc.makeCommand( CMD_MOVE,posRightTop.getX(),posRightTop.getY(),0.0);
	        else
	          soc.makeCommand( CMD_MOVE,posLeftTop.getX(), posLeftTop.getY(), 0.0);
	        ACT->putCommandInQueue( soc );
	      }
	      else if( WM->getTimeSinceLastCatch() > 28 )
	      {
	        soc = kickTo( VecPosition(0,posAgent.getY()*2.0), 2.0 );
	        ACT->putCommandInQueue( soc );
	      }
	      else if( WM->getTimeSinceLastCatch() < 25 )
	      {
	        VecPosition posSide( 0.0, posAgent.getY() );
	        if( fabs( (posSide - posAgent).getDirection() - angBody) > 10 )
	        {
	          soc = turnBodyToPoint( posSide );
	          ACT->putCommandInQueue( soc );
	        }
	        ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	      }
	    }
	    else if( WM->isGoalKickUs()  )
	    {
	      ACT->putCommandInQueue( soc = intercept( true ) );
	      ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	    }
	    else
	      ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  }
	  else
	  {
	     ACT->putCommandInQueue( soc = turnBodyToObject( OBJECT_BALL ) );
	     ACT->putCommandInQueue( turnNeckToObject( OBJECT_BALL, soc ) );
	  }
	  return soc;
}



/*! Metodo que retorna uma determinada flag do campo, levando em conta o lado do
    campo em que o time esta jogando e a posicao Y do agente. O retorno desse
    metodo e uma flag da lateral defensiva para uso especifico do goleiro em
    situacao de clear ball.

    \param VecPosition posAgent em que o goleiro esta localizado
    \param int contador que indica qual flag deve ser retornada
    \return ObjectT correspondente a flag da lateral defensiva do campo */
ObjectT Player::getFlagClearBallGoleiro(VecPosition posAgent, int contador){

	ObjectT flag = OBJECT_UNKNOWN;

	if(WM->getSide() == SIDE_LEFT){
		switch(contador){
		    case 1 || 5: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_T_L_50 : OBJECT_FLAG_B_L_50; break;
		    case 2: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_T_L_40 : OBJECT_FLAG_B_L_40; break;
		    case 3: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_T_L_30 : OBJECT_FLAG_B_L_30; break;
		    case 4: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_T_L_20 : OBJECT_FLAG_B_L_20; break;
	    }
	}
	else{
		switch(contador){
		    case 1 || 5: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_B_R_50 : OBJECT_FLAG_T_R_50; break;
		    case 2: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_B_R_40 : OBJECT_FLAG_T_R_40; break;
		    case 3: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_B_R_30 : OBJECT_FLAG_T_R_30; break;
		    case 4: flag = (WM->isEsquerda(posAgent))? OBJECT_FLAG_B_R_20 : OBJECT_FLAG_T_R_20; break;
	    }
	}
	return flag;
}


/*! Metodo que decide o lado que o jogador de linha deve chutar, em caso de
    clear ball, de acordo com a sua posicao no campo.

    \return SoccerCommand chute para uma area livre */
SoccerCommand Player::clearBallPlayer(){

	if(WM->isEsquerda(WM->getAgentGlobalPosition())){
	    return clearBall(CLEAR_BALL_DEFENSIVE,SIDE_LEFT);
	}
    else{
	    return clearBall(CLEAR_BALL_DEFENSIVE,SIDE_RIGHT);
	}
}

/*! This method returns the position to move in case of a dead ball situation.
    A dead ball situation occurs when the team can have a free kick, kick in,
    etc. The agent will move to the position behind the ball and when he is
    there will move to the ball again.

    \return VecPosition position behind the ball where the agent must to move */
VecPosition Player::getDeadBallPosition(){
    VecPosition pos, posBall = WM->getBallPos();
    VecPosition posAgent = WM->getAgentGlobalPosition();
    double dDist;

    // determine point to move to
    if( WM->isKickInUs()  )
        pos = posBall + VecPosition( -1.5, sign( posBall.getY() )*1.5 );
    else if( WM->isCornerKickUs( ) )
        pos = posBall + VecPosition( 1.5, sign( posBall.getY() ) * 1.5 );
    else if( WM->isFreeKickUs()  || WM->isOffsideThem()       ||
             WM->isGoalKickUs()  || WM->isFreeKickFaultThem() ||
             WM->isBackPassThem() )
            pos = posBall + VecPosition( -1.5, 0.0 );
    else
        return VecPosition( UnknownDoubleValue, UnknownDoubleValue );

    AngDeg      angBall = (posBall-posAgent).getDirection() ;
    ObjectT     obj = WM->getClosestInSetTo( OBJECT_SET_PLAYERS,
                                             WM->getAgentObjectType(), &dDist);
    VecPosition posPlayer = WM->getGlobalPosition( obj );

    // change point when heading towards other player or towards the ball
    if( fabs( angBall - (posPlayer-posAgent).getDirection() ) < 20 && dDist < 6 )
        pos -= VecPosition( 5, 0 );
    if( fabs( angBall -  (pos-posAgent).getDirection()) < 20 ){
        angBall = VecPosition::normalizeAngle( angBall - 90 );
        pos = posBall + VecPosition( 1, angBall , POLAR );
    }
    return pos;
}



/*!This method determines whether a player should say something.

    \return bool indicating whether the agent should say a message */
bool Player::shallISaySomething( SoccerCommand socPri ){
    bool        bReturn;

    bReturn  = ((WM->getCurrentTime() - m_timeLastSay) >= SS->getHearDecay());
    bReturn  &= amIAgentToSaySomething( socPri );
    bReturn  &= (WM->getCurrentCycle() > 0 );

    return bReturn;
}

/*! This method returns a boolean indicating whether I should communicate my
    world model to the other agents.

    \return boolean indicating whether I should communicate my world model. */
bool Player::amIAgentToSaySomething( SoccerCommand socPri ){
    double  dDist;
    ObjectT obj;

    // get the closest teammate to the ball, if we are not him, we do not
    // communicate since he will
    obj = WM->getClosestInSetTo( OBJECT_SET_TEAMMATES,OBJECT_BALL,&dDist);
    if( dDist < SS->getVisibleDistance() &&
        obj != WM->getAgentObjectType() )
        return false;

    // in the defense, player 6 keeps track of the opponent attacker
    if( WM->getBallPos().getX() < - PENALTY_X + 4.0 &&
        WM->getConfidence( OBJECT_BALL ) > 0.96 &&
        WM->getPlayerNumber() == 6 && WM->getCurrentCycle() % 3 == 0 ){

        // once very 3 cycles is enough
        Log.log( 600, "player 6 is going to communicate attacker info" );
        return true;
    }

    if(WM->isGoodBallInformation(socPri))
        return true;

    return false;
}

/*! This method encodes the opponent attacker status in a visual message.

    \return string in which the opponent attacker position is encoded.*/
void Player::sayOppAttackerStatus( char* strMsg ){
    char    strTmp[MAX_SAY_MSG];

    // fill the first byte with some encoding to indicate the current cycle.
    // The second byte   is the last digit of the cycle added to 'a'.
    sprintf( strMsg, "%c", 'a' + WM->getCurrentCycle()%10   );

    // fill the second byte with information about the offside line.
    // Enter either a value between a-z or A-Z indicating. This gives 52 possible
    // values which correspond with meters on the field. So B means the offside
    // line lies at 27.0.
    int iOffside = (int)WM->getOffsideX();
    if( iOffside < 26 ) // 0..25
        sprintf( strTmp, "%c", 'a' + iOffside );
    else               // 26...
        sprintf( strTmp, "%c", 'A' + max(iOffside - 26, 25) );
    strcat( strMsg, strTmp );

    // find the closest opponent attacker to the penalty spot.
    double dDist ;
    ObjectT objOpp = WM->getClosestInSetTo( OBJECT_SET_OPPONENTS,
                                            VecPosition(- PITCH_LENGTH/2.0 + 11.0, 0 ),
                                            &dDist  ) ;

    if( objOpp == OBJECT_ILLEGAL || dDist >= 20.0 ){
        strncpy( strMsg, "", 0 );
        return;
    }

    VecPosition posOpp = WM->getGlobalPosition( objOpp );
    if( fabs( posOpp.getY() ) > 10 ){
        strncpy( strMsg, "", 0 );
        return;
    }

    // encode the position of this attacker in the visual message. The
    // player_number is the third byte, then comes the x position in 3 digits (it
    // is assumed this value is always negative), a space and finally the y
    // position in 2 digits. An example of opponent nr. 9 at position
    // (-40.3223,-3.332) is "j403 -33)
    sprintf( strTmp, "%c%d %d", 'a' + SoccerTypes::getIndex( objOpp ) ,
                                  (int)(fabs(posOpp.getX())*10),
                                  (int)(posOpp.getY()*10));
    strcat( strMsg, strTmp );

    return ;
}

/*! This method creates a string to communicate the ball status. When
    the player just kicks the ball, it is the new velocity of the
    ball, otherwise it is the current velocity.

    \param strMsg will be filled */
void Player::sayBallStatus( char * strMsg  ){
    VecPosition posBall = WM->getGlobalPosition( OBJECT_BALL );
    VecPosition velBall = WM->getGlobalVelocity( OBJECT_BALL );
    int iDiff = 0;
    SoccerCommand soc = ACT->getPrimaryCommand();

    if( WM->getRelativeDistance( OBJECT_BALL ) < SS->getMaximalKickDist() ){
        // if kick and a pass
        if( soc.commandType == CMD_KICK ){
            WM->predictBallInfoAfterCommand( soc, &posBall, &velBall );
            VecPosition posAgent = WM->predictAgentPos( 1, 0 );
            if( posBall.getDistanceTo( posAgent ) > SS->getMaximalKickDist() + 0.2 )
                iDiff = 1;
        }
        if( iDiff == 0 ){
            posBall = WM->getGlobalPosition( OBJECT_BALL );
            velBall.setVecPosition( 0, 0 );
        }
    }
    Log.log( 600, "create comm. ball after: (%1.2f,%1.2f)(%1.2f,%1.2f) diff %d",
             posBall.getX(), posBall.getY(), velBall.getX(), velBall.getY(), iDiff);
    makeBallInfo( posBall, velBall, iDiff, strMsg );
}

/*! This method is used to create the communicate message for the
    status of the ball, that is its position and velocity is encoded.

    \param VecPosition posBall ball position
    \param VecPosition velBall ball velocity
    \param iDiff time difference corresponding to given ball information
    \strMsg string message in which the ball information is encoded. */
void Player::makeBallInfo( VecPosition posBall, VecPosition velBall,
                           int         iDiff,   char        * strMsg  ){
    char    strTmp[MAX_SAY_MSG];

    // fill the first byte with some encoding to indicate the next cycle.
    // The second byte is the last digit of the cycle added to 'a'.
    sprintf( strMsg, "%c", 'a' + (WM->getCurrentCycle()+iDiff)%10   );

    // fill the second byte with information about the offside line.
    // Enter either a value between a-z or A-Z indicating. This gives 52 possible
    // values which correspond with meters on the field. So B means the offside
    // line lies at 27.0.
    int iOffside = (int)( WM->getOffsideX( false ) - 1.0 );
    if( iOffside < 26 ) // 0..25
        sprintf( strTmp, "%c", 'a' + max( 0, iOffside) );
    else               // 26...
        sprintf( strTmp, "%c", 'A' + min(iOffside - 26, 25) );
    strcat( strMsg, strTmp );

    // First add al values to a positive interval, since then we don't need
    // another byte for the minus sign. then take one digit at a time
    double x = max(0,min( rint( posBall.getX() + 48.0), 99.0));
    sprintf( strTmp, "%c%c%c%c%c%c%c%c",
            '0' + ((int)( x                          ) % 100 ) / 10 ,
            '0' + ((int)( x                          ) % 100 ) % 10 ,
            '0' + ((int)( rint(posBall.getY() + 34.0)) % 100 ) / 10 ,
            '0' + ((int)( rint(posBall.getY() + 34.0)) % 100 ) % 10 ,
            '0' + ((int)(( velBall.getX() + 2.7) * 10 )) / 10 ,
            '0' + ((int)(( velBall.getX() + 2.7) * 10 )) % 10 ,
            '0' + ((int)(( velBall.getY() + 2.7) * 10 )) / 10 ,
            '0' + ((int)(( velBall.getY() + 2.7) * 10 )) % 10 );
    strcat( strMsg, strTmp );
    Log.log( 6560, "say (%d) %s\n", WM->getPlayerNumber() , strMsg );

    return ;
}

/*! Metodo para escrever uma mensagem padronizada na saida padrao. Antes da
    mensagem desejada sera exibido o numero do agente e o ciclo atual, muito
    util para debug.

    \param char* msg mensagem que se deseja exibir no formato padrao */
void Player::escreverLog(char *msg){
		cout<<"J"<<WM->getPlayerNumber()<<"-"<<WM->getCurrentCycle()
			<<": "<<msg<<"\n";
}

/*!This method listens for input from the keyboard and when it receives this
   input it converts this input to the associated action. See
   showStringCommands for the possible options. This method is used together
   with the SenseHandler class that sends an alarm to indicate that a new
   command can be sent. This conflicts with the method in this method that
   listens for the user input (fgets) on Linux systems (on Solaris this isn't a
   problem). The only known method is to use the flag SA_RESTART with this
   alarm function, but that does not seem to work under Linux. If each time
   the alarm is sent, this gets function unblocks, it will cause major
   performance problems. This function should not be called when a whole match
   is played! */
void Player::handleStdin( ){
    char buf[MAX_MSG];

    while( bContLoop ){
        #ifdef WIN32
            cin.getline( buf, MAX_MSG );
        #else
            fgets( buf, MAX_MSG, stdin ); // does unblock with signal !!!!!
        #endif
        printf( "after fgets: %s\n", buf );
        executeStringCommand( buf );
    }
}

/*! This method prints the possible commands that can be entered by the user.
    The whole name can be entered to perform the corresponding command, but
    normally only the first character is sufficient. This is indicated by
    putting brackets around the part of the command that is not needed.

    \param out output stream to which the possible commands are printed */
void Player::showStringCommands( ostream& out ){
    out << "Basic commands:"                                << endl <<
           " a(ctions)"                                     << endl <<
           " c(atch) direction"                             << endl <<
           " cs(lientsettings"                              << endl <<
           " d(ash) power [ times ]"                        << endl <<
           " de(bug) nr_cycles"                             << endl <<
           " g(oto) x y"                                    << endl <<
           " h(elp)"                                        << endl <<
           " i(ntercept) x y"                               << endl <<
           " k(ick) power angle"                            << endl <<
           " ka x y endspeed "                              << endl <<
           " m(ove) x y"                                    << endl <<
           " n(eck) angle"                                  << endl <<
           " o(pponents in cone) width dist"                << endl <<
           " p(redict cycles to) x y"                       << endl <<
           " q(uit)"                                        << endl <<
           " s(ay) message"                                 << endl <<
           " ss(erversettings)"                             << endl <<
           " t(urn) angle"                                  << endl <<
           " v(iewmode) narrow | normal | wide low | high"  << endl <<
           " w(orldmodel)"                                  << endl;
}

/*! This method executes the command that is entered by the user. For the
    possible command look at the method showStringCommands.

    \param str string that is entered by the user
    \return true when command could be executed, false otherwise */
bool Player::executeStringCommand( char *str){
    SoccerCommand socCommand;
    int           i;
    double        x, y;

    switch( str[0] ){
        case 'a':                                 // actions
            WM->showQueuedCommands();
        break;
        case 'c':                                 // catch dir or cs
            if( strlen(str) > 1 && str[1] == 's' ){
                PS->show( cout, ":" );
                break;
            }
            socCommand.makeCommand( CMD_CATCH, Parse::parseFirstInt( &str ) );
        break;
        case 'd':                                 // dash
            socCommand.commandType = CMD_DASH;
            socCommand.dPower      = Parse::parseFirstDouble( &str );
            socCommand.iTimes      = Parse::parseFirstInt   ( &str );
            if( socCommand.iTimes == 0 ){
                socCommand.iTimes = 1;
            }
        break;
        case 'h':                                // help
            showStringCommands( cout );
        return true;
        case 'k':                                // kick or ka (kick advanced)
            socCommand.commandType = CMD_KICK;
            if( str[1] == 'a' ){ // advanced kick
                double x = Parse::parseFirstDouble( &str );
                double y = Parse::parseFirstDouble( &str );
                double e = Parse::parseFirstDouble( &str );
                socCommand = kickTo( VecPosition( x, y), e );
            }
            else{
                socCommand.dPower = Parse::parseFirstDouble( &str );
                socCommand.dAngle = Parse::parseFirstDouble( &str );
            }
        break;
        case 'm':                               // move
            socCommand.commandType = CMD_MOVE;
            socCommand.dX          = Parse::parseFirstDouble( &str );
            socCommand.dY          = Parse::parseFirstDouble( &str );
            socCommand.dAngle      = Parse::parseFirstDouble( &str );
        break;
        case 'n':                              // turn_neck
            socCommand.commandType = CMD_TURNNECK;
            socCommand.dAngle      = Parse::parseFirstDouble( &str );
        break;
        case 'o':                              // count nr opp in cone
            x = Parse::parseFirstDouble( &str );
            y = Parse::parseFirstDouble( &str );
            i = WM->getNrInSetInCone( OBJECT_SET_OPPONENTS, x,
                                      WM->getAgentGlobalPosition(),
                                      WM->getAgentGlobalPosition() +
                                      VecPosition( y,WM->getAgentGlobalNeckAngle(),
                                                   POLAR ) );
            printf( "%d opponents\n", i );
        return true;
        case 'p':                              // predict cycles to point
            x = Parse::parseFirstDouble( &str );
            y = Parse::parseFirstDouble( &str );
            i = WM->predictNrCyclesToPoint( WM->getAgentObjectType(),
                                            VecPosition( x, y ) );
            printf( "%d cycles\n", i );
        return true;
        case 'q':                             // quit
            bContLoop = false;
        return true;
        case 's':                             // ss (serversettings) or say
            if( strlen(str) > 1 && str[1] == 's' ){
                SS->show( cout, ":" );
                break;
            }
            socCommand.commandType = CMD_SAY;
            Parse::gotoFirstOccurenceOf( ' ', &str );
            Parse::gotoFirstNonSpace( &str );
            strcpy( socCommand.str, str);
        break;
        case 't':                             // turn
            socCommand.commandType = CMD_TURN;
            socCommand.dAngle      = Parse::parseFirstDouble( &str );
        break;
        case 'v':                             // change_view
            socCommand.commandType = CMD_CHANGEVIEW;
            Parse::gotoFirstOccurenceOf(' ', &str );
            Parse::gotoFirstNonSpace( &str );
            socCommand.va          = SoccerTypes::getViewAngleFromStr( str );
            Parse::gotoFirstOccurenceOf(' ', &str );
            Parse::gotoFirstNonSpace( &str );
            socCommand.vq          = SoccerTypes::getViewQualityFromStr( str );
        break;
        case 'w':                            // worldmodel
            WM->show();
        return true;
        default:                             // default: send entered string
            ACT->sendMessage( str );
        return true;
    }
    if( socCommand.commandType != CMD_ILLEGAL ) // when socCommand is set
        ACT->putCommandInQueue( socCommand );     // send it.

    return true;
}
