#ifndef PLAYER
#define PLAYER

#include "BasicPlayer.h"
#include "Formations.h"     // needed for Formations

void* stdin_callback( void * v );


/*! This class is a subclass from BasicPlayer and contains a more
    sophisticated decision procedure to determine the next action. */
class Player:public BasicPlayer
{
    ActHandler   *ACT;         /*!< ActHandler to which commands can be sent */
    Formations   *formations;            /*!< all formation information      */
    bool          bContLoop;             /*!< is server is alive             */

    Time          m_timeLastSay;         /*!< last time communicated         */
    ObjectT       m_objMarkOpp;          /*!< last marked opponent           */
    ObjectT       m_objPassOption;       /*!< passing option in kick         */
    int           m_iPenaltyNr;          /*!< number of current penalty      */
    ActionT       m_actionPrev;          /*!< previous action of this agent  */


    /* ACOES*/
    //PENALTY
    SoccerCommand performPenalty            (                                 );
    SoccerCommand performPenaltyGoalKeeper  (                                 );
    SoccerCommand performPenaltyPlayer      (                                 );
    SoccerCommand posicionamentoPenaltyGoleiro(                               );
    SoccerCommand acaoDefesaPenalty         (                                 );
    SoccerCommand posicionamentoPenaltyPlayer(                                );
    SoccerCommand acaoCobrancaPenalty       (                                 );
    bool          isChutePenalty            (                                 );
    bool          isCobrarPenalty           (                                 );

    //BOLA PARADA
    SoccerCommand bolaParada                (                                 );
    SoccerCommand bolaParadaJogadorLinha    (                                 );
    SoccerCommand bolaParadaGoleiro         (                                 );
    SoccerCommand bolaParadaAdversario      (                                 );

    //KICKOFF
    SoccerCommand acaoBeforeKickOff         (                                 );
    SoccerCommand acaoKickOff               (                                 );

    //PLAYMODE_ON POR TIPO (BOLA ROLANDO)
    SoccerCommand acaoGoleiroPlayOn         (                                 );
    SoccerCommand acaoLateralPlayOn         (                                 );
    SoccerCommand acaoZagueiroPlayOn        (                                 );
    SoccerCommand acaoMeiaDefensivoPlayOn   (                                 );
    SoccerCommand acaoMeiaOfensivoPlayOn    (                                 );
    SoccerCommand acaoAtacantePlayOn        (                                 );

    SoccerCommand acaoDummyLinha			(                                 );
    SoccerCommand acaoDummyGoleiro			(                                 );

    SoccerCommand acaoBolaKickable          (                                 );
    // ACÕES COM BOLA NO PÉ POR ZONA
    SoccerCommand acaoDefesa                (                                 );
    SoccerCommand acaoMeioCampoATT          (                                 );
    SoccerCommand acaoGrandeAreaATT         (                                 );
    SoccerCommand acaoLateralATT            (                                 );
    SoccerCommand acaoIntermediariaATT      (                                 );
    SoccerCommand acaoLinhaDeFundoATT       (                                 );

    //CHUTE A GOL
    void          areaBloqueadaGol          ( int segmentos[]                 );
    void          melhorAreaChute           ( int segmentos[],
                                              int &total,
                                              int &ind                        );
    VecPosition   melhorPosicaoChute        (                                 );
    SoccerCommand bicuda                    ( VecPosition posChute            );

    //PASSE
    double        relevanciaPasse           ( ObjectT companheiro             );
    ObjectT       melhorCompanheiroPasse    ( double *maiorPossi              );
    bool          isPasseSeguro             ( VecPosition posCompanheiro,
                                              VecPosition Origem              );
    //CRUZAMENTO
    bool          cruzar                    ( double distAFrente,
                                              double raio,
                                              SoccerCommand &soc              );
    bool          isCompanheiroBemPosicionado( ObjectT companheiro,
                                               PassT tipoPasse                );

    //MARCAÇÃO
    bool          temCompanheiroProximo     ( VecPosition posOpont            );
    ObjectT       quemMarcar                (                                 );
    bool          isPosicionar              (                                 );
    float         decisaoMarkBallBisect     ( float entradas[4]               );
    bool          isForaPosicaoEstrategicaMarcacao(                           );

    //CONDUZIR
    SoccerCommand conduzir                  ( bool reto = true                );

    //POSICIONAMENTO
    bool          isForaPosicaoEstrategica  (                                 );
    SoccerCommand posicionamentoEscanteioDEF(                                 );
    SoccerCommand posicionamentoFaltaDEF    (                                 );

    //GOLEIRO
    bool          isLinhaDePasseSegura      ( ObjectT teammate,
                                              VecPosition posAgent            );
    bool          isCompanheiroMarcado2     ( VecPosition companheiro,
                                              double raio                     );
    ObjectT       getFlagClearBallGoleiro   ( VecPosition posAgent,
                                              int contador                    );
    SoccerCommand clearBallGoleiro		    (                                 );
    SoccerCommand passeGoleiro              ( double raio,
                                              VecPosition posGoleiro          );
    SoccerCommand reposicaoGoleiro          ( double raio                     );

    //UTILITÁRIOS
    bool          isCompanheiroMarcado1     ( VecPosition posCompanheiro,
                                              double raioInterno,
                                              double raioExterno              );
    double        velocidadePasse           ( double distancia,
                                              PassT passe                     );
    SoccerCommand girarParaGolAdversario    (                                 );
    SoccerCommand clearBallPlayer           (                                 );
    VecPosition   getDeadBallPosition       (                                 );

    //MÉTODOS DE DECISÃO
    SoccerCommand acaoPasseConduzir         ( double indicePossibilidade      );
    bool          isChute                   ( VecPosition posChute            );
    bool          isInterceptarBola         (                                 );

    //PESCOÇO
    void          controladorPescoco        ( SoccerCommand socPrimary        );

    // methods associated with saying
    bool          shallISaySomething        ( SoccerCommand  soc              );
    bool          amIAgentToSaySomething    ( SoccerCommand  soc              );
    void          sayOppAttackerStatus      ( char *         str              );
    void          sayBallStatus             ( char *         str              );
    void          makeBallInfo              ( VecPosition    posBall,
                                              VecPosition    velBall,
                                              int            iDiff,
                                              char *         str              );

    //DEBUG
    void          escreverLog               ( char *msg                       );

public:
    Player                                  ( ActHandler     *a,
                                              WorldModel     *wm,
                                              ServerSettings *ss,
                                              PlayerSettings *cs,
                                              Formations     *fs,
                                              char           *strTeamName,
                                              double         dVersion,
                                              int            iReconnect = -1  );

    void          mainLoop                  (                                 );


    // methods that deal with user input (from keyboard) to sent commands
    void          handleStdin               (                                 );
    void          showStringCommands        ( ostream& out                    );
    bool          executeStringCommand      ( char *str                       );
};

#endif
